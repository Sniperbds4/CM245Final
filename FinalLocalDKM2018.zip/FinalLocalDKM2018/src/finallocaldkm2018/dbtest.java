/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finallocaldkm2018;

import java.io.File;

/**
 *
 * @author student
 */
public class dbtest {
    public static void main (String args[]){
File f = new File("DBDriverInfo.properties");
System.out.println(f.getAbsolutePath());
    }
    
}
